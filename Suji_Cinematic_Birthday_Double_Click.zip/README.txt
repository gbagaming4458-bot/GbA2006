SUJI CINEMATIC BIRTHDAY PAGE

WINDOWS: Double-click START_SUJI.bat to open the birthday page in your default browser.
You can also double-click index.html directly.

To edit the message, open index.html in Notepad or VS Code and search for: const message=
